default_library_v3
==================

Sample template for the DPS default ios7 library. The accompanying zip can be uploaded as is to App Builder.

For more information about DPS custom stores visit http://blogs.adobe.com/digitalpublishing/2012/04/build-a-custom-store-to-promote-in-app-sales.html and http://www.adobe.com/devnet/digitalpublishingsuite/custom-storefronts-and-libraries.html.

To configure this template visit the configurator, https://www.dpsapps.com/dpsapps/store_configurator/.


http://www.adobe.com/support/downloads/license.html
